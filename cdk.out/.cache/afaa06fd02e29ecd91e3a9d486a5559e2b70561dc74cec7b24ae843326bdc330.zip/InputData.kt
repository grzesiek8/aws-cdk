package lambda.resources

data class InputData(
        val name: String = ""
)